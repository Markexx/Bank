﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public class Redemption : Transaction
    {
        public Redemption(IBankAccount account, decimal amount) : base(account, amount) { }

        public override void ExecuteTransaction()
        {
            BankAccount.Deposit(Amount);
            Console.WriteLine($"Redemption made from {Amount} to account.");
        }
    }
}
