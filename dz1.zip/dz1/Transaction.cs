﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public abstract class Transaction : ITransaction
    {
        public IBankAccount BankAccount { get; set; }
        public decimal Amount { get; set; }

        public Transaction(IBankAccount bankAccount, decimal amount)
        {
            BankAccount = bankAccount;
            Amount = amount;
        }
        public abstract void ExecuteTransaction();
    }
}
