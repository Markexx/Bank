﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public static class Test
    {
        public static void RunTask()
        {
            Bank bank = new Bank();

            User user1 = new User("Marko", "Marković");
            User user2 = new User("Pero", "Perić");

            bank.AddUser(user1);
            bank.AddUser(user2);

            user1.DisplayAccountInfo();
            user2.DisplayAccountInfo();

            user1.Deposit(1000);
            user2.Deposit(500);
            user2.Withdraw(200);

            user1.DisplayAccountInfo();
            user2.DisplayAccountInfo();



        }
    }
}
