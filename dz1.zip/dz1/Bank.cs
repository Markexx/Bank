﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public class Bank
    {
        private List<User> users;
        private List<Transaction> transactions;

        public Bank() 
        {
            users = new List<User>();
            transactions = new List<Transaction>();
        }

        public void AddUser(User user)
        {
            users.Add(user);
        }

        public void RemoveUser(User user)
        {
            users.Remove(user);
        }

        public void ExecuteTransaction(ITransaction transaction)
        {
            transaction.ExecuteTransaction();
        }
    }
}
