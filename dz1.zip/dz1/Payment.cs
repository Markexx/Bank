﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public class Payment : Transaction
    {

        public Payment(IBankAccount account, decimal amount) : base(account, amount) { }

        public override void ExecuteTransaction()
        {
            BankAccount.Withdraw(Amount);
            Console.WriteLine($"Payment made from {Amount} to account.");
        }
    }

}
