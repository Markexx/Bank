﻿namespace dz1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Test.RunTask();
        }
    }
}
