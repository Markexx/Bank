﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public class User : Person, IBankAccount
    {
        public decimal Balance {get; set;}

        public User(string firstName, string lastName) : base(firstName, lastName)
        {
            FirstName = firstName;
            LastName = lastName;
            Balance = 0;
        }

        public void Withdraw(decimal amount)
        {
            if (amount > Balance)
            {
                Console.WriteLine("Insufficient funds.");
                return;
            }
            Balance -= amount;
        }

        public void Deposit(decimal amount)
        {
            Balance += amount;
        }

        public decimal GetBalance()
        {
            return Balance;
        }

        public void DisplayAccountInfo()
        {
            Console.WriteLine($"Account Holder: {FirstName} {LastName}");
            Console.WriteLine($"Balance: {Balance}");
        }
    }

}
