﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dz1
{
    public interface IBankAccount
    {
        public void Deposit(decimal amount);
        public void Withdraw(decimal amount);
        public void DisplayAccountInfo();

    }
}
